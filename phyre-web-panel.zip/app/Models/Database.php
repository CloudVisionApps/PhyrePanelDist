<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Database extends Model
{
    use HasFactory;

    protected $fillable = [
        'hosting_subscription_id',
        'name',
        'username',
        'password',
        'description',
    ];


    public function databaseUsers()
    {
        return $this->hasMany(DatabaseUser::class);
    }
}
