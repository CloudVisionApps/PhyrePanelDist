<?php

namespace App\Models;

use App\Events\ModelDomainCreated;
use App\Events\ModelDomainDeleting;
use Illuminate\Database\Eloquent\Model;

class Domain extends Model
{
    protected $fillable = [
        'domain',
        'domain_root',
        'ip',
        'hosting_subscription_id',
    ];

    public static function boot()
    {
        parent::boot();

        static::created(function ($model) {
            event(new ModelDomainCreated($model));
        });

        static::deleting(function ($model) {
            event(new ModelDomainDeleting($model));
        });

    }

    public function configureVirtualHost()
    {
        $findHostingSubscription = \App\Models\HostingSubscription::where('id', $this->hosting_subscription_id)
            ->first();
        if (!$findHostingSubscription) {
            return;
        }

        $findHostingPlan = \App\Models\HostingPlan::where('id', $findHostingSubscription->hosting_plan_id)
            ->first();
        if (!$findHostingPlan) {
            return;
        }

        $apacheVirtualHostBuilder = new \App\VirtualHosts\ApacheVirtualHostBuilder();
        $apacheVirtualHostBuilder->setDomain($this->domain);
        $apacheVirtualHostBuilder->setDomainPublic($this->domain_public);
        $apacheVirtualHostBuilder->setDomainRoot($this->domain_root);
        $apacheVirtualHostBuilder->setHomeRoot($this->home_root);
        $apacheVirtualHostBuilder->setUser($findHostingSubscription->system_username);
        $apacheVirtualHostBuilder->setUserGroup('www-data');
        $apacheVirtualHostBuilder->setAdditionalServices([]);

        $apacheBaseConfig = $apacheVirtualHostBuilder->buildConfig();

        if (!empty($apacheBaseConfig)) {
            file_put_contents('/etc/apache2/sites-available/'.$this->domain.'.conf', $apacheBaseConfig);
            shell_exec('ln -s /etc/apache2/sites-available/'.$this->domain.'.conf /etc/apache2/sites-enabled/'.$this->domain.'.conf');
        }


        $findDomainSSLCertificate = \App\Models\DomainSslCertificate::where('domain', $this->domain)
            ->first();

        if ($findDomainSSLCertificate) {

            $sslCertificateFile = $this->home_root . '/certs/' . $this->domain . '/public/cert.pem';
            $sslCertificateKeyFile = $this->home_root . '/certs/' . $this->domain . '/private/key.private.pem';
            $sslCertificateChainFile = $this->home_root . '/certs/' . $this->domain . '/public/fullchain.pem';

            if (!empty($findDomainSSLCertificate->certificate)) {
                if (!is_dir($this->home_root . '/certs/' . $this->domain . '/public')) {
                    mkdir($this->home_root . '/certs/' . $this->domain . '/public', 0755, true);
                }
                file_put_contents($sslCertificateFile, $findDomainSSLCertificate->certificate);
            }
            if (!empty($findDomainSSLCertificate->private_key)) {
                if (!is_dir($this->home_root . '/certs/' . $this->domain . '/private')) {
                    mkdir($this->home_root . '/certs/' . $this->domain . '/private', 0755, true);
                }
                file_put_contents($sslCertificateKeyFile, $findDomainSSLCertificate->private_key);
            }
            if (!empty($findDomainSSLCertificate->certificate_chain)) {
                if (!is_dir($this->home_root . '/certs/' . $this->domain . '/public')) {
                    mkdir($this->home_root . '/certs/' . $this->domain . '/public', 0755, true);
                }
                file_put_contents($sslCertificateChainFile, $findDomainSSLCertificate->certificate_chain);
            }


            $apacheVirtualHostBuilder->setPort(443);
            $apacheVirtualHostBuilder->setSSLCertificateFile($sslCertificateFile);
            $apacheVirtualHostBuilder->setSSLCertificateKeyFile($sslCertificateKeyFile);
            $apacheVirtualHostBuilder->setSSLCertificateChainFile($sslCertificateChainFile);

            $apacheBaseConfigWithSSL = $apacheVirtualHostBuilder->buildConfig();

            if (!empty($apacheBaseConfigWithSSL)) {
                file_put_contents('/etc/apache2/sites-available/'.$this->domain.'-ssl.conf', $apacheBaseConfigWithSSL);
                shell_exec('ln -s /etc/apache2/sites-available/'.$this->domain.'-ssl.conf /etc/apache2/sites-enabled/'.$this->domain.'-ssl.conf');
            }

            shell_exec('systemctl reload apache2');

        }
        
    }
}
