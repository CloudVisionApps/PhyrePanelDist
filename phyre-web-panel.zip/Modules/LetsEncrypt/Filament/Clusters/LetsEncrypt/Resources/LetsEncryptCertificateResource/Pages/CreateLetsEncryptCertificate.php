<?php

namespace Modules\LetsEncrypt\Filament\Clusters\LetsEncryptResource\Pages;
use Modules\LetsEncrypt\Filament\Admin\Resources\LetsEncryptCertificateResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLetsEncryptCertificate extends CreateRecord
{
    protected static string $resource = LetsEncryptCertificateResource::class;
}
