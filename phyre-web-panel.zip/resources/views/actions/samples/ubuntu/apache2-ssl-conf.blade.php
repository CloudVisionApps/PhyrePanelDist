<IfModule mod_ssl.c>
    <VirtualHost *:{{$port}}>

        ServerName {{$domain}}
        DocumentRoot {{$domainPublic}}
        SetEnv APP_DOMAIN {{$domain}}

        <Directory {{$domainPublic}}>
        Options Indexes FollowSymLinks MultiViews
        AllowOverride All
        Require all granted

        </Directory>

        SSLCertificateFile {{$sslCertificateFilePath}}
        SSLCertificateKeyFile {{$sslCertificateKeyFilePath}}
        SSLCertificateChainFile {{$sslCertificateChainFilePath}}

        Include /etc/apache2/phyre/options-ssl-apache.conf
    </VirtualHost>
</IfModule>
