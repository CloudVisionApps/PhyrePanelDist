<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {

    if (file_exists(storage_path('installed'))) {
        return redirect('/admin');
    }

    return view('welcome');

});

Route::get('dev', function () {

    $create = new \App\Models\PhyreServer();
    $create->name = 'hetzner1';
    $create->ip = '37.27.28.220';
    $create->port = '22';
    $create->username = 'root';
    $create->password = 'WTuiMuxqpdMLWv3b3Nxv';
    $create->save();


});
