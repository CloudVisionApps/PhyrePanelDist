<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\LetsEncrypt\\App\\Providers\\LetsEncryptServiceProvider',
    1 => 'Modules\\LetsEncrypt\\Providers\\Filament\\AdminPanelProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\LetsEncrypt\\App\\Providers\\LetsEncryptServiceProvider',
    1 => 'Modules\\LetsEncrypt\\Providers\\Filament\\AdminPanelProvider',
  ),
  'deferred' => 
  array (
  ),
);