<?php

namespace App\Models;

use App\ShellApi;
use Illuminate\Database\Eloquent\Model;

class HostingDatabase extends Model
{
    protected $fillable = [
        'database_name',
        'database_username',
        'database_password',
    ];

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {

            $createDbAndUser = ShellApi::callBin('mysql-create-db-and-user', [
                $model->database_name,
                $model->database_username,
                $model->database_password,
            ]);

            if (empty($createDbAndUser)) {
                return false;
            }

        });

        static::deleting(function ($model) {

        });
    }
}
