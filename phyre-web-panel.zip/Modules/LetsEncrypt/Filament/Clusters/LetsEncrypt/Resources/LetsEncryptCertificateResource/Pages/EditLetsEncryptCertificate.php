<?php

namespace Modules\LetsEncrypt\Filament\Clusters\LetsEncryptResource\Pages;
use Modules\LetsEncrypt\Filament\Admin\Resources\LetsEncryptCertificateResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditLetsEncryptCertificate extends EditRecord
{
    protected static string $resource = LetsEncryptCertificateResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
