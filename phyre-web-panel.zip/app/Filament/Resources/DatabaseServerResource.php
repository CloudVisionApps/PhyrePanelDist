<?php

namespace App\Filament\Resources;

use App\Filament\Resources\DatabaseServerResource\Pages;
use App\Filament\Resources\DatabaseServerResource\RelationManagers;
use App\Models\DatabaseServer;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class DatabaseServerResource extends Resource
{
    protected static ?string $model = DatabaseServer::class;

    protected static ?string $navigationIcon = 'heroicon-o-circle-stack';

    protected static ?string $navigationGroup = 'Server Clustering';

    protected static ?int $navigationSort = 1;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('name')
                    ->label('Name')
                    ->required()
                    ->placeholder('Enter a name for this server'),

                Forms\Components\Select::make('database_type')
                    ->label('Database Type')
                    ->required()
                    ->options([
                        'mysql' => 'MySQL',
                        'mariadb' => 'MariaDB',
                        'mongodb' => 'MongoDB',
                        'postgresql' => 'PostgreSQL',
                        'sqlite' => 'SQLite',
                        'sqlserver' => 'SQL Server',
                    ]),

                Forms\Components\TextInput::make('ip')
                    ->label('IP Address')
                    ->required()
                    ->placeholder('Enter the ip address of the server'),

                Forms\Components\TextInput::make('port')
                    ->label('Port')
                    ->required()
                    ->placeholder('Enter the port of the server'),

                Forms\Components\TextInput::make('username')
                    ->label('Username')
                    ->required()
                    ->placeholder('Enter the username of the server'),

                Forms\Components\TextInput::make('password')
                    ->label('Password')
                    ->required()
                    ->placeholder('Enter the password of the server'),


            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                //
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListDatabaseServers::route('/'),
            'create' => Pages\CreateDatabaseServer::route('/create'),
            'edit' => Pages\EditDatabaseServer::route('/{record}/edit'),
        ];
    }
}
