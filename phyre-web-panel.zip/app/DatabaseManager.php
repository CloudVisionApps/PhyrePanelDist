<?php

namespace App;

use Doctrine\DBAL\DriverManager;
use Doctrine\DBAL\Query;

class DatabaseManager
{
    public $host;
    public $port;

    public $username;
    public $password;

    public $database =  null;

    public function __construct($host, $port, $username, $password, $database)
    {
        $this->host = $host;
        $this->port = $port;

        $this->username = $username;
        $this->password = $password;

        $this->database = $database;
    }

    public function createDatabase($databaseName)
    {
        $connectionParams = [
            'user' => $this->username,
            'password' => $this->password,
            'host' => $this->host,
            'port' => $this->port,
            'driver' => 'pdo_mysql',
        ];

        $connection = DriverManager::getConnection($connectionParams);
        $connection->connect();
        if (!$connection->isConnected()) {
            throw new \Exception('Could not connect to database');
        }

        try {
            $resultSet = $connection->executeQuery('CREATE DATABASE ' . $databaseName);

            return $resultSet;
        } catch (\Exception $e) {
            return false;
        }

    }

    public function deleteDatabase($databaseName)
    {

    }

    public function createDatabaseUser($username, $password)
    {

    }
    public function deleteDatabaseUser($username)
    {

    }

}
