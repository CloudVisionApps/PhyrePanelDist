<?php

namespace App\Filament\Resources\HostingSubscriptionResource\Pages;

use App\Filament\Resources\HostingSubscriptionResource;
use Filament\Resources\Pages\CreateRecord;

class CreateHostingSubscription extends CreateRecord
{
    protected static string $resource = HostingSubscriptionResource::class;
}
