<?php

namespace App\Listeners;

use App\Actions\ApacheWebsiteCreate;
use App\Events\DomainIsCreated;
use App\Events\ModelDomainCreated;
use App\Models\Domain;
use App\Models\HostingPlan;
use App\Models\HostingSubscription;

class ModelDomainCreatedListener
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     */
    public function handle(ModelDomainCreated $event): void
    {
        $findDomain = Domain::where('id', $event->model->id)->first();
        if (! $findDomain) {
            return;
        }
        $findHostingSubscription = HostingSubscription::where('id', $findDomain->hosting_subscription_id)->first();
        if (! $findHostingSubscription) {
            return;
        }

        $findHostingPlan = HostingPlan::where('id', $findHostingSubscription->hosting_plan_id)->first();
        if (! $findHostingPlan) {
            return;
        }

        $newApacheWebsite = new ApacheWebsiteCreate();
        $newApacheWebsite->setDomain($findDomain->domain);
        $newApacheWebsite->setUser($findHostingSubscription->system_username);
        $newApacheWebsite->setAdditionalServices($findHostingPlan->additional_services);
        $newApacheWebsite->setFeatures($findHostingPlan->features);
        if ($findDomain->is_main) {
            $newApacheWebsite->setIsMainDomain(true);
        }

        $create = $newApacheWebsite->handle();

        if (! empty($create)) {

            $findDomain->home_root = $create['homeRoot'];
            $findDomain->domain_root = $create['domainRoot'];
            $findDomain->domain_public = $create['domainPublic'];
            $findDomain->save();

            event(new DomainIsCreated($findDomain));
        }

    }
}
