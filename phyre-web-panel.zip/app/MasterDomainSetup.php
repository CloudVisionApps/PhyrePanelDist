<?php

namespace App;

class MasterDomainSetup
{
    public $domain;

    public $email;
    public $documentRoot = '/var/www/html';

    public $wildcard = false;

    public function __construct($domain, $email = null)
    {
        $this->domain = $domain;
        $this->email = $email;
    }

    public function enableWildcard()
    {
        $this->wildcard = true;
    }
    public function install()
    {
        $domainPublic = '/var/www/html';

        $apacheVirtualHostBuilder = new \App\VirtualHosts\ApacheVirtualHostBuilder();
        $apacheVirtualHostBuilder->setDomain($this->domain);

        if ($this->wildcard) {
            $apacheVirtualHostBuilder->setDomainAlias('*.' . $this->domain);
        }

        $apacheVirtualHostBuilder->setDomainPublic($domainPublic);
        $apacheVirtualHostBuilder->setDomainRoot($domainPublic);
        $apacheVirtualHostBuilder->setHomeRoot($domainPublic);
        $apacheVirtualHostBuilder->setServerAdmin($this->email);

        $apacheBaseConfig = $apacheVirtualHostBuilder->buildConfig();

        if (!empty($apacheBaseConfig)) {
            file_put_contents('/etc/apache2/sites-available/000-default.conf', $apacheBaseConfig);
            shell_exec('ln -s /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-enabled/000-default.conf');
        }

        $indexContent = view('actions.samples.apache.html.app-index-html')->render();
        file_put_contents($domainPublic . '/index.html', $indexContent);

        shell_exec('chown -R www-data:www-data ' . $domainPublic);
        shell_exec('chmod -R 755 ' . $domainPublic);
        shell_exec('systemctl restart apache2');
    }
}
