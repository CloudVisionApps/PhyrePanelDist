<?php

namespace App\Filament\Resources\DatabaseServerResource\Pages;

use App\Filament\Resources\DatabaseServerResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditDatabaseServer extends EditRecord
{
    protected static string $resource = DatabaseServerResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
