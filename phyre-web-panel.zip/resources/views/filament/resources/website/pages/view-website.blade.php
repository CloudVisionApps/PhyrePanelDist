<x-filament-panels::page>

    <h3>
        {{$this->record->domain}}
    </h3>

</x-filament-panels::page>
