<?php

namespace App\Filament\Resources\DatabaseServerResource\Pages;

use App\Filament\Resources\DatabaseServerResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListDatabaseServers extends ListRecords
{
    protected static string $resource = DatabaseServerResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
