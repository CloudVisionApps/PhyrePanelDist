<?php

namespace App\Models;

use App\DatabaseManager;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DatabaseUser extends Model
{
    use HasFactory;

    protected $fillable = [
        'database_id',
        'username',
        'password',
    ];


    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {

            $findDatabase = Database::where('id', $model->database_id)->first();
            if (!$findDatabase) {
                return false;
            }
            if ($findDatabase->is_remote_database_server) {
                $findRemoteDatabaseServer = RemoteDatabaseServer::where('id', $findDatabase->remote_database_server_id)->first();
                if (!$findRemoteDatabaseServer) {
                    return false;
                }

                $databaseManager = new DatabaseManager(
                    $findRemoteDatabaseServer->host,
                    $findRemoteDatabaseServer->port,
                    $findRemoteDatabaseServer->username,
                    $findRemoteDatabaseServer->password,
                    $findDatabase->database_name
                );

                if (!$databaseManager->createUser($model->username, $model->password)){
                    return false;
                }
            }

        });
    }

    public function database()
    {
        return $this->belongsTo(Database::class);
    }

}
