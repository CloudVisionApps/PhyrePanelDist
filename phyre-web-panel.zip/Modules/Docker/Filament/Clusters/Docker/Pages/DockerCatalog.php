<?php

namespace Modules\Docker\Filament\Clusters\Docker\Pages;

use Filament\Actions\Action;
use Filament\Forms\Components\Actions;
use Filament\Forms\Components\Grid;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Pages\Page;
use Modules\Docker\App\Models\DockerImage;
use Modules\Docker\Filament\Clusters\DockerCluster;

class DockerCatalog extends Page implements HasForms
{
    use InteractsWithForms;

    // protected static ?string $navigationGroup = 'Docker';

    protected static ?string $cluster = DockerCluster::class;

    protected static ?string $navigationIcon = 'heroicon-o-cog';

    protected static ?int $navigationSort = 1;

    protected static string $view = 'docker::filament.pages.docker-catalog';

    protected function getViewData(): array
    {
        $findImages = DockerImage::limit(10)->get();
        return [
            'dockerImages' => $findImages->toArray(),
        ];
    }
    protected function getFormSchema(): array
    {
        return [
            TextInput::make('keyword')
                ->placeholder('Search for docker images...')
                ->label('Search'),

            Grid::make('3')
                ->schema([

                    Toggle::make('official')
                        ->label('Official'),

                    Toggle::make('automated')
                        ->label('Automated'),

                    Toggle::make('starred')
                        ->label('Starred'),

                    Actions::make([
                        Actions\Action::make('search')
                            ->label('Search for docker images')
                            ->action('search'),
                    ]),
                ])
        ];
    }

}
