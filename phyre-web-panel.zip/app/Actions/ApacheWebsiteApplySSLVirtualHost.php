<?php

namespace App\Actions;

use App\FileManagerApi;
use App\ShellApi;

class ApacheWebsiteApplySSLVirtualHost
{
    public $domain;

    public $domainRoot;

    public $domainPublic;

    public $sslCertificateFilePath;

    public $sslCertificateKeyFilePath;

    public $sslCertificateChainFilePath;

    public function setSslCertificateFilePath($sslCertificateFilePath)
    {
        $this->sslCertificateFilePath = $sslCertificateFilePath;
    }

    public function setSslCertificateKeyFilePath($sslCertificateKeyFilePath)
    {
        $this->sslCertificateKeyFilePath = $sslCertificateKeyFilePath;
    }

    public function setSslCertificateChainFilePath($sslCertificateChainFilePath)
    {
        $this->sslCertificateChainFilePath = $sslCertificateChainFilePath;
    }

    public function setDomain($domain)
    {
        $this->domain = $domain;
    }

    public function setDomainPublic($domainPublic)
    {
        $this->domainPublic = $domainPublic;
    }

    public function setDomainRoot($domainRoot)
    {
        $this->domainRoot = $domainRoot;
    }

    public function handle()
    {
        $settings = [
            'port' => 443,
            'domain' => $this->domain,
            'domainRoot' => $this->domainRoot,
            'domainPublic' => $this->domainPublic,
            'group' => 'www-data',
            'sslCertificateFilePath' => $this->sslCertificateFilePath,
            'sslCertificateKeyFilePath' => $this->sslCertificateKeyFilePath,
            'sslCertificateChainFilePath' => $this->sslCertificateChainFilePath,
        ];
        $apache2SSLSample = view('actions.samples.ubuntu.apache2-ssl-conf', $settings)->render();

        $fileManagerApi = new FileManagerApi();

        $apache2SSLOptionsSample = view('actions.samples.ubuntu.apache2-ssl-options-conf')->render();
        $apache2SSLOptionsFilePath = '/etc/apache2/phyre/options-ssl-apache.conf';
        if (! $fileManagerApi->isDir('/etc/apache2/phyre')) {
            $fileManagerApi->mkdir('/etc/apache2/phyre');
        }
        if (! $fileManagerApi->fileExists($apache2SSLOptionsFilePath)) {
            $fileManagerApi->filePutContents($apache2SSLOptionsFilePath, $apache2SSLOptionsSample);
        }

        $fileManagerApi->filePutContents('/etc/apache2/sites-available/'.$this->domain.'-ssl.conf', $apache2SSLSample);
        $fileManagerApi->symlink('/etc/apache2/sites-available/'.$this->domain.'-ssl.conf', '/etc/apache2/sites-enabled/'.$this->domain.'-ssl.conf');

        ShellApi::exec('service apache2 restart');

    }
}
