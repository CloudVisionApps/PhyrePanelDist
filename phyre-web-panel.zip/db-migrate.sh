PHYRE_PHP=/usr/local/phyre/php/bin/php

rm -rf composer.lock
$PHYRE_PHP composer.phar i
$PHYRE_PHP composer.phar dump-autoload

$PHYRE_PHP artisan migrate

#$PHYRE_PHP artisan l5-swagger:generate
