<?php

namespace App\Models;

use App\Events\ModelDomainCreated;
use App\Events\ModelDomainDeleting;
use Illuminate\Database\Eloquent\Model;

class Domain extends Model
{
    protected $fillable = [
        'domain',
        'domain_root',
        'ip',
        'hosting_subscription_id',
    ];

    public static function boot()
    {
        parent::boot();

        static::created(function ($model) {
            event(new ModelDomainCreated($model));
        });

        static::deleting(function ($model) {
            event(new ModelDomainDeleting($model));
        });

    }
}
