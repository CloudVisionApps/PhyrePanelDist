<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Microweber\\App\\Providers\\MicroweberServiceProvider',
    1 => 'Modules\\Microweber\\Providers\\Filament\\AdminPanelProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Microweber\\App\\Providers\\MicroweberServiceProvider',
    1 => 'Modules\\Microweber\\Providers\\Filament\\AdminPanelProvider',
  ),
  'deferred' => 
  array (
  ),
);