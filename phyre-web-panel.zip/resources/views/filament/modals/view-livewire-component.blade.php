<div>
    @livewire($component, $componentProps, key($component))
</div>
