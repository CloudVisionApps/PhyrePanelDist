<?php

namespace Modules\LetsEncrypt\Filament\Clusters\LetsEncrypt\Pages;

use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Modules\LetsEncrypt\Filament\Clusters\LetsEncryptCluster;
use Outerweb\FilamentSettings\Filament\Pages\Settings as BaseSettings;

class MasterDomain extends BaseSettings
{
    protected static ?string $navigationGroup = 'Let\'s Encrypt';

    protected static ?string $cluster = LetsEncryptCluster::class;

    protected static ?string $navigationIcon = 'heroicon-o-adjustments-horizontal';

    protected static ?int $navigationSort = 3;

    public static function getNavigationLabel() : string
    {
        return 'Master Domain';
    }
    public function schema(): array
    {
        return [

            Section::make('MasterDomain')
                ->schema([

                    TextInput::make('master_domain')
                        ->placeholder(setting('general.master_domain'))
                        ->disabled(),


                ]),
        ];
    }
}
