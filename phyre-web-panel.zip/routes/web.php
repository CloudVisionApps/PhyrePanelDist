<?php

use Illuminate\Support\Facades\Route;
use phpseclib3\Net\SSH2;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {

    if (file_exists(storage_path('installed'))) {
        return redirect('/admin');
    }

    return view('welcome');

});

Route::get('dev', function () {

    $phyreServer = \App\Models\PhyreServer::find(15);

    $ssh = new SSH2($phyreServer->ip);
    if ($ssh->login($phyreServer->username, $phyreServer->password)) {
        dd($ssh->exec('cat phyre-install.log'));
    }

//    $create = new \App\Models\PhyreServer();
//    $create->name = 'hetzner1';
//    $create->ip = 'random-ip';
//    $create->port = '22';
//    $create->username = 'root';
//    $create->password = 'random-pass';
//    $create->save();


});
