<div class="flex flex-col justify-center items-center h-screen text-center">
    <div class="w-[66rem]">
        {{$this->form}}
    </div>

</div>
