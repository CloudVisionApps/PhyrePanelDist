<?php

namespace Modules\LetsEncrypt\Filament\Clusters\LetsEncrypt\Pages;

use App\ApiClient;
use App\MasterDomainSetup;
use App\Models\DomainSslCertificate;
use App\Settings;
use Filament\Actions\Action;
use Filament\Forms\Components\Checkbox;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Wizard;
use Modules\LetsEncrypt\Filament\Clusters\LetsEncryptCluster;
use Outerweb\FilamentSettings\Filament\Pages\Settings as BaseSettings;

class WildcardMasterDomain extends BaseSettings
{
    protected static ?string $navigationGroup = 'Let\'s Encrypt';

    protected static ?string $cluster = LetsEncryptCluster::class;

    protected static ?string $navigationIcon = 'heroicon-o-adjustments-horizontal';

    protected static ?int $navigationSort = 2;

    public $install_log = '';

    public static function getNavigationLabel() : string
    {
        return 'Wildcard Master Domain';
    }
    public function getFormActions() : array
    {
        return [

        ];
    }

    public function installCertificates()
    {

        $findCertificate = DomainSslCertificate::where('domain', setting('general.master_domain'))->first();
        if ($findCertificate) {

            $mds = new MasterDomainSetup(
                setting('general.master_domain'),
                setting('general.master_email')
            );
            $mds->install();
            return;
        }


        $generalSettings = Settings::general();

        $masterDomain = $generalSettings['master_domain'];
        $masterDomainRoot = '/var/www';
        $masterDomainPublic = '/var/www/html';

        $acmeConfigYaml = view('letsencrypt::actions.acme-config-yaml', [
            'domain' => $masterDomain,
            'domainRoot' => $masterDomainRoot,
            'domainPublic' => $masterDomainPublic,
            'email' => $generalSettings['master_email'],
            'country' => $generalSettings['master_country'],
            'locality' => $generalSettings['master_locality'],
            'organization' => $generalSettings['organization_name'],
            'wildcard' => true,
        ])->render();
        $acmeConfigYaml = preg_replace('~(*ANY)\A\s*\R|\s*(?!\r\n)\s$~mu', '', $acmeConfigYaml);


        file_put_contents($masterDomainRoot.'/acme-config.yaml', $acmeConfigYaml);

        $amePHPPharFile = base_path().'/Modules/LetsEncrypt/Actions/acmephp.phar';

        $phyrePHP = ApiClient::getPhyrePHP();

        $command = $phyrePHP.' '.$amePHPPharFile.' run '.$masterDomainRoot.'/acme-config.yaml';
        $execSSL = shell_exec($command);

        $validateCertificates = [];
        $sslCertificateFilePath = '/root/.acmephp/master/certs/'.$masterDomain.'/public/cert.pem';
        $sslCertificateKeyFilePath = '/root/.acmephp/master/certs/'.$masterDomain.'/private/key.private.pem';
        $sslCertificateChainFilePath = '/root/.acmephp/master/certs/'.$masterDomain.'/public/fullchain.pem';

        if (! file_exists($sslCertificateFilePath)
            || ! file_exists($sslCertificateKeyFilePath)
            || ! file_exists($sslCertificateChainFilePath)) {
            // Cant get all certificates
            return;
        }

        $sslCertificateFileContent = file_get_contents($sslCertificateFilePath);
        $sslCertificateKeyFileContent = file_get_contents($sslCertificateKeyFilePath);
        $sslCertificateChainFileContent = file_get_contents($sslCertificateChainFilePath);

        if (! empty($sslCertificateChainFileContent)) {
            $validateCertificates['certificate'] = $sslCertificateFileContent;
        }
        if (! empty($sslCertificateKeyFileContent)) {
            $validateCertificates['private_key'] = $sslCertificateKeyFileContent;
        }
        if (! empty($sslCertificateChainFileContent)) {
            $validateCertificates['certificate_chain'] = $sslCertificateChainFileContent;
        }
        if (count($validateCertificates) !== 3) {
            // Cant get all certificates
            return;
        }

        $websiteSslCertificate = new DomainSslCertificate();
        $websiteSslCertificate->domain = $masterDomain;
        $websiteSslCertificate->certificate = $validateCertificates['certificate'];
        $websiteSslCertificate->private_key = $validateCertificates['private_key'];
        $websiteSslCertificate->certificate_chain = $validateCertificates['certificate_chain'];
        $websiteSslCertificate->customer_id = 0;
        $websiteSslCertificate->is_active = 1;
        $websiteSslCertificate->is_wildcard = 0;
        $websiteSslCertificate->is_auto_renew = 1;
        $websiteSslCertificate->provider = 'letsencrypt';
        $websiteSslCertificate->save();

        dd($websiteSslCertificate);
    }

    public function installLog()
    {
        $installLog = file_get_contents('/var/www/acme-wildcard-install.log');
        $installLog = str_replace("\n", "<br>", $installLog);
        $this->install_log = $installLog;

    }

    public function schema(): array
    {
        return [

            Wizard::make([
                Wizard\Step::make('Install')
                    //->description('Install a wildcard SSL certificate for the master domain')
                    ->schema([
                        TextInput::make('master_domain')
                            ->helperText('Install a wildcard SSL certificate for the master domain')
                            ->placeholder(setting('general.master_domain'))
                            ->disabled(),
                    ])->afterValidation(function () {

                        $generalSettings = Settings::general();
                        $masterDomain = $generalSettings['master_domain'];
                        $masterDomainRoot = '/var/www';
                        $masterDomainPublic = '/var/www/html';
                        $logFilePath =  '/var/www/acme-wildcard-install.log';

                        if (file_exists($logFilePath)) {
                            unlink($logFilePath);
                        }

                        $acmeConfigWildcardYaml = view('letsencrypt::actions.acme-config-wildcard-yaml', [
                            'domain' => $masterDomain,
                            'domainRoot' => $masterDomainRoot,
                            'domainPublic' => $masterDomainPublic,
                            'email' => $generalSettings['master_email'],
                            'country' => $generalSettings['master_country'],
                            'locality' => $generalSettings['master_locality'],
                            'organization' => $generalSettings['organization_name']
                        ])->render();


                        file_put_contents($masterDomainRoot.'/acme-wildcard-config.yaml', $acmeConfigWildcardYaml);
                        $amePHPPharFile = base_path().'/Modules/LetsEncrypt/Actions/acmephp.phar';
                        $phyrePHP = ApiClient::getPhyrePHP();
                        $command = $phyrePHP.' '.$amePHPPharFile.' run '.$masterDomainRoot.'/acme-wildcard-config.yaml >> ' . $logFilePath . ' &';
                        $execSSL = shell_exec($command);

                    }),
                Wizard\Step::make('Verification')
                   // ->description('Adding TXT record in DNS zone to verify domain ownership')
                    ->schema([

                       TextInput::make('install_log')
                           ->view('livewire.installer-install-log')
                           ->label('Installation Log'),

                    ]),
                Wizard\Step::make('Finish')
                    ->schema([
                        // ...
                    ]),
            ]),
        ];
    }
}
