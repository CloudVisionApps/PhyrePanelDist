<div>
    <div class="bg-black/5 p-4 rounded">
    {!! $this->containerLog !!}
    </div>
</div>
