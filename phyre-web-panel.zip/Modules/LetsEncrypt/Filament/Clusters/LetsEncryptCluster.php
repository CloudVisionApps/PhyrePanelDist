<?php

namespace Modules\LetsEncrypt\Clusters;

use Filament\Clusters\Cluster;

class LetsEncryptCluster extends Cluster
{
    protected static ?string $navigationIcon = 'heroicon-o-squares-2x2';

    protected static ?string $navigationGroup = 'Server Management';

    public static function getLabel(): string
    {
        return 'LetsEncrypt';
    }
}
