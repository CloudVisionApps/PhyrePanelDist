<x-filament-panels::page>

    <div>

        @vite('resources/js/web-terminal.js')

        <div id="js-web-terminal"></div>

    </div>

</x-filament-panels::page>
