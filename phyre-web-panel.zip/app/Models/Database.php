<?php

namespace App\Models;

use App\DatabaseManager;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Database extends Model
{
    use HasFactory;

    protected $fillable = [
        'hosting_subscription_id',
        'remote_database_server_id',
        'is_remote_database_server',
        'name',
        'description',
    ];

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {

            $findHostingSubscription = HostingSubscription::where('id', $model->hosting_subscription_id)->first();
            if (!$findHostingSubscription) {
                return false;
            }

            if ($model->is_remote_database_server == 'yes') {
                $remoteDatabaseServer = RemoteDatabaseServer::find($model->remote_database_server_id);
                if (!$remoteDatabaseServer) {
                    return false;
                }

                $databaseManager = new DatabaseManager(
                    $remoteDatabaseServer->host,
                    $remoteDatabaseServer->port,
                    $remoteDatabaseServer->username,
                    $remoteDatabaseServer->password,
                    null
                );

                $model->name = Str::slug($model->name, '_');
                $databaseName = $findHostingSubscription->system_username . '_' . $model->name;

                if ($databaseManager->createDatabase($databaseName)) {
                    $model->name = $databaseName;
                } else {
                    return false;
                }

            }


        });
    }

    public function hostingSubscription()
    {
        return $this->belongsTo(HostingSubscription::class);
    }

    public function databaseUsers()
    {
        return $this->hasMany(DatabaseUser::class);
    }
}
