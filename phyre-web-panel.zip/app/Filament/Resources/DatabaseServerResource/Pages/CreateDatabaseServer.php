<?php

namespace App\Filament\Resources\DatabaseServerResource\Pages;

use App\Filament\Resources\DatabaseServerResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDatabaseServer extends CreateRecord
{
    protected static string $resource = DatabaseServerResource::class;
}
