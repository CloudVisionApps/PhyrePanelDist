<?php

namespace Modules\LetsEncrypt\Filament\Clusters\LetsEncrypt\Pages;

use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Modules\LetsEncrypt\Filament\Clusters\LetsEncryptCluster;
use Outerweb\FilamentSettings\Filament\Pages\Settings as BaseSettings;

class Settings extends BaseSettings
{
    protected static ?string $navigationGroup = 'Let\'s Encrypt';

    protected static ?string $cluster = LetsEncryptCluster::class;

    protected static ?string $navigationIcon = 'heroicon-o-cog';

    protected static ?int $navigationSort = 3;

    public function schema(): array
    {
        return [

            Section::make('Settings')
                ->schema([

                    TextInput::make('email')
                        ->label('Email')
                        ->placeholder('Email')
                        ->required(),

                    Select::make('server')
                        ->label('Server')
                        ->placeholder('Server')
                        ->options([
                            'https://acme-v02.api.letsencrypt.org/directory' => 'Production',
                            'https://acme-staging-v02.api.letsencrypt.org/directory' => 'Staging',
                        ])
                        ->required(),

                ]),
        ];
    }
}
