<?php

namespace App\Livewire;

use App\Models\User;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Wizard;
use Filament\Forms\Form;
use Filament\Pages\Page;
use Filament\Support\Exceptions\Halt;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\HtmlString;
use JaOcero\RadioDeck\Forms\Components\RadioDeck;
use Livewire\Component;

class Installer extends Page
{

    protected static string $layout = 'filament-panels::components.layout.base';

    protected static string $view = 'livewire.installer';

    public $step = 1;

    public $name;

    public $email;

    public $password;

    public $password_confirmation;

    public $livewire = true;


    public function form(Form $form): Form
    {

        $step1 = [
            TextInput::make('name')
                ->label('Name')
                ->required(),

            TextInput::make('email')
                ->label('Email')
                ->required()
                ->email(),

            TextInput::make('password')
                ->label('Password')
                ->required()
                ->password(),

            TextInput::make('password_confirmation')
                ->label('Confirm Password')
                ->same('password')
                ->required()
                ->password(),
        ];

        $findUserCount = User::count();
        if ($findUserCount >= 1) {
            $step1 = [


                Section::make()
                    ->heading('Admin user account already created')
                    ->description('You can continue to configure your hosting server.')


            ];
        }


            return $form
            ->schema([

                Wizard::make([

                    Wizard\Step::make('Step 1')
                        ->description('Create your admin account')
                        ->schema($step1)->afterValidation(function () use ($findUserCount) {

                            if ($findUserCount == 0) {
                                $createUser = new User();
                                $createUser->name = $this->name;
                                $createUser->email = $this->email;
                                $createUser->password = bcrypt($this->password);
                                $createUser->save();
                            }

                        }),

                    Wizard\Step::make('Step 2')
                        ->description('Configure your hosting server')
                        ->schema([

                            RadioDeck::make('server_application_type')
                                ->default('apache_php')
                                ->options([
                                    'apache_php' => 'Apache + PHP',
                                    'apache_nodejs' => 'Apache + Node.js',
                                    'apache_python' => 'Apache + Python',
                                    'apache_ruby' => 'Apache + Ruby',
                                ])
                                ->icons([
                                    'apache_php' => 'si-php',
                                    'apache_nodejs' => 'tni-nodejs',
                                    'apache_python' => 'si-python',
                                    'apache_ruby' => 'si-ruby',
                                ])
                                ->descriptions([
                                    'apache_php' => 'Install applications like WordPress, Joomla, Drupal and more.',
                                    'apache_nodejs' => 'Install applications like Ghost, KeystoneJS, and more.',
                                    'apache_python' => 'Install applications like Django, Flask, and more.',
                                    'apache_ruby' => 'Install applications like Ruby on Rails, Sinatra, and more.',
                                ])
                                ->required()
                                ->color('primary')
                                ->columns(3),

                        ]),

                    Wizard\Step::make('Step 3')
                        ->description('Finish installation')
                        ->schema([

                        ])

                ])
                    ->persistStepInQueryString()
                    ->startOnStep(2)
                    ->submitAction(new HtmlString(Blade::render(<<<BLADE
                        <x-filament::button
                            type="submit"
                            size="sm"
                            color="primary"
                            wire:click="install"
                        >
                            Submit
                        </x-filament::button>
                    BLADE)))

            ]);
    }

    public function install()
    {
        dd(33);
    }

    public function __install()
    {
        $this->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:8|confirmed',
            'password_confirmation' => 'required|min:8',
        ]);

        $createUser = new User();
        $createUser->name = $this->name;
        $createUser->email = $this->email;
        $createUser->password = bcrypt($this->password);
        $createUser->save();

        file_put_contents(storage_path('installed'), 'installed-'.date('Y-m-d H:i:s'));

        return redirect('/admin/login');

    }


//if (file_exists(storage_path('installed'))) {
//return redirect('/admin');
//}

}
