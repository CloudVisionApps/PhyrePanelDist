<?php

namespace Modules\LetsEncrypt\Filament\Clusters;

use Filament\Clusters\Cluster;

class LetsEncryptCluster extends Cluster
{
    protected static ?string $navigationIcon = 'heroicon-o-shield-check';

    protected static ?string $navigationGroup = 'Server Management';

}
