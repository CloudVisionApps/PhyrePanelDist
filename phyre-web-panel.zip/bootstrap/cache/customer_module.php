<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Customer\\App\\Providers\\CustomerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Customer\\App\\Providers\\CustomerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);