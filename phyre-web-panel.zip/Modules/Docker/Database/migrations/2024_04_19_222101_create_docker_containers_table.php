<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('docker_containers', function (Blueprint $table) {
            $table->id();

            $table->string('name');
            $table->string('command');
            $table->string('docker_id');
            $table->string('image');
            $table->longText('labels');
            $table->string('local_volumes');
            $table->string('mounts');
            $table->string('names');
            $table->string('networks');
            $table->string('ports');
            $table->string('running_for');
            $table->string('size');
            $table->string('state');
            $table->string('status');

            $table->longText('environment_variables');


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('docker_containers');
    }
};
