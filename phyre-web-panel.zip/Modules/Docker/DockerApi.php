<?php

namespace Modules\Docker;

class DockerApi
{
    public $logFile = '';

    public function setLogFile($logFile)
    {
        $this->logFile = $logFile;
    }

    public function runImage($name)
    {
        $commandId = rand(10000, 99999);
        $commands = [];
        $commands[] = 'docker pull ' . $name;
        $commands[] = 'docker run -d ' . $name;
        $commands[] = 'docker ps -a';
        $commands[] = 'docker logs ' . $name;

        $shellFileContent = '';

        foreach ($commands as $command) {
            $shellFileContent .= $command . PHP_EOL;
        }

        $shellFileContent .= 'echo "DONE!"' . PHP_EOL;
        $shellFileContent .= 'rm -f /tmp/docker-run-image-'.$commandId.'.sh';

        file_put_contents('/tmp/docker-run-image-'.$commandId.'.sh', $shellFileContent);
        shell_exec('bash /tmp/docker-run-image-'.$commandId.'.sh >> ' . $this->logFile . ' &');

    }

    public function searchImages($keyword, $filters = [])
    {
        $filtersString = ''; // --filter is-official=true

        $output = shell_exec('docker search --format "{{json .}}" --no-trunc '.$filtersString.' ' . $keyword);
        $output = trim($output);
        $output = str_replace("\n", ',', $output);
        $output = '[' . $output . ']';
        $dockerSearch = json_decode($output, true);

        if ($dockerSearch === null) {
            return [];
        }

        return $dockerSearch;
    }

    public function getContainers()
    {
        $output = shell_exec('docker ps -a --format "{{json .}}"');
        $output = trim($output);
        $output = str_replace("\n", ',', $output);
        $output = '[' . $output . ']';
        $dockerContainers = json_decode($output, true);

        if ($dockerContainers === null) {
            return [];
        }

        return $dockerContainers;
    }
}
