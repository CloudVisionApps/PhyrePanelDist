<?php

namespace Modules\Docker\Filament\Clusters\Docker\Pages;

use Filament\Actions\Action;
use Filament\Forms\Components\Actions;
use Filament\Forms\Components\Checkbox;
use Filament\Forms\Components\Grid;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Tabs;
use Filament\Forms\Components\Tabs\Tab;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Pages\Page;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Str;
use Modules\Docker\App\Models\DockerContainer;
use Modules\Docker\App\Models\DockerImage;
use Modules\Docker\DockerApi;
use Modules\Docker\Filament\Clusters\DockerCluster;

class DockerCatalog extends Page implements HasForms
{
    use InteractsWithForms;

    // protected static ?string $navigationGroup = 'Docker';

    protected static ?string $cluster = DockerCluster::class;

    protected static ?string $navigationIcon = 'heroicon-o-cog';

    protected static ?int $navigationSort = 1;

    protected static string $view = 'docker::filament.pages.docker-catalog';

    public $keyword = '';
    public $filterOfficial = true;
    public $filterAutomated = true;
    public $filterStarred = true;

    public $runLog = '';
    public $runLogFile = '';
    public $runLogPulling = false;

    public $dockerContainers = [];

    public function search()
    {
        $this->validate([
            'keyword' => 'required|string',
        ]);

        Artisan::call('docker:search-images ' . $this->keyword);
    }

    public function getRunLog()
    {
        if (file_exists($this->runLogFile)) {
            $logContent = file_get_contents($this->runLogFile);
            $this->runLog = str_replace("\n", "<br>", $logContent);
        }
        if (str_contains($this->runLog, 'DONE!')) {
            $this->runLogPulling = false;
            $this->dispatch('close-modal', id: 'run-docker-image');
        }
    }

    public function runDockerImage($dockerImageName)
    {
        $dockerImage = DockerImage::where('name', $dockerImageName)->first();
        if ($dockerImage) {
            $this->dispatch('open-modal', id: 'run-docker-image');

            $dockerLogPath = storage_path('logs/docker/run-'.Str::slug($dockerImageName).'.log');
            if (!is_dir(dirname($dockerLogPath))) {
                shell_exec('mkdir -p '.dirname($dockerLogPath));
            }
            $this->runLogFile = $dockerLogPath;

            $dockerApi = new DockerApi();
            $dockerApi->setLogFile(storage_path('logs/docker/run-'.Str::slug($dockerImageName).'.log'));
            $dockerApi->runImage($dockerImage->name);

            $this->runLogPulling = true;

            $this->getRunLog();
        }
    }

    protected function getViewData(): array
    {
        $findImagesQuery = DockerImage::query();
        if ($this->keyword) {
            $findImagesQuery->where('name', 'like', '%' . $this->keyword . '%');
        }
        $findImages = $findImagesQuery->get();

        $findDockerContainers = DockerContainer::get();

        return [
            'dockerImages' => $findImages->toArray(),
            'dockerContainers' => $findDockerContainers->toArray(),
        ];
    }
    protected function getFormSchema(): array
    {
        return [

            TextInput::make('keyword')
                ->placeholder('Search for docker images...')
                ->label('Search'),

            Grid::make('4')
                ->schema([

                    Checkbox::make('filterOfficial')
                        ->label('Official'),

                    Checkbox::make('filterAutomated')
                        ->label('Automated'),

                    Checkbox::make('filterStarred')
                        ->label('Starred'),

                    Actions::make([
                        Actions\Action::make('search')
                            ->label('Search for docker images')
                            ->action('search'),
                    ]),
                ])

        ];
    }

}
