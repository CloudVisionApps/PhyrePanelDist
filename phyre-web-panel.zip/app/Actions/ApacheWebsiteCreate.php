<?php

namespace App\Actions;

class ApacheWebsiteCreate
{
    public $domain;

    public $user;

    public $email;

    public $password;

    public $isMainDomain = false;

    public $additionalServices = [];

    public $features = [];

    public function setDomain($domain)
    {
        $this->domain = $domain;
    }

    public function setUser($user)
    {
        $this->user = $user;
    }

    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function setPassword($password)
    {
        $this->password = $password;
    }

    public function setAdditionalServices($additionalServices)
    {
        $this->additionalServices = $additionalServices;
    }

    public function setFeatures($features)
    {
        $this->features = $features;
    }

    public function setIsMainDomain($isMainDomain)
    {
        $this->isMainDomain = $isMainDomain;
    }

    public function handle()
    {
//        $getLinuxUser = new GetLinuxUser();
//        $getLinuxUser->setUsername($this->user);
//        $linuxUser = $getLinuxUser->handle();
//
//        if (empty($linuxUser)) {
//            return false;
//        }

        $linuxUser = $this->user;

        if ($this->isMainDomain) {
            $allDomainsRoot = '/home/'.$this->user.'/public_html';
            $domainRoot = '/home/'.$this->user;
            $domainPublic = '/home/'.$this->user.'/public_html';
            $homeRoot = '/home/'.$this->user;
        } else {
            $allDomainsRoot = '/home/'.$this->user.'/domains';
            $domainRoot = '/home/'.$this->user.'/domains/'.$this->domain;
            $domainPublic = $domainRoot.'/public_html';
            $homeRoot = '/home/'.$this->user;
        }

        $apacheVirtualHostConfigs = app()->virtualHostManager->getConfigs($this->additionalServices);

        $settings = [
            'port' => 80,
            'domain' => $this->domain,
            'domainPublic' => $domainPublic,
            'domainRoot' => $domainRoot,
            'homeRoot' => $homeRoot,
            'user' => $this->user,
            'group' => 'www-data',
            'enableRuid2' => true,
        ];

        $settings = array_merge($settings, $apacheVirtualHostConfigs);
        $apache2Sample = view('actions.samples.ubuntu.apache2-conf', $settings)->render();

        if (! is_dir($homeRoot)) {
            mkdir($homeRoot);
        }
        if (! is_dir($allDomainsRoot)) {
            mkdir($allDomainsRoot);
        }
        if (! is_dir($domainRoot)) {
            mkdir($domainRoot);
        }
        if (! is_dir($domainPublic)) {
            mkdir($domainPublic);
        }

        shell_exec('chmod -R 775 /etc/apache2/sites-available/');

        file_put_contents('/etc/apache2/sites-available/'.$settings['domain'].'.conf', $apache2Sample);

        shell_exec('ln -s /etc/apache2/sites-available/'.$settings['domain'].'.conf /etc/apache2/sites-enabled/'.$settings['domain'].'.conf');
        
        $indexContent = '

<?php print_r($_ENV); ?>
<?php echo get_current_user(); ?>
<?php echo phpinfo(); ?>

';

        file_put_contents($settings['domainPublic'].'/index.php', $indexContent);

        shell_exec('chown -R '.$settings['user'].':'.$settings['group'].' '.$allDomainsRoot);
        shell_exec('chown -R '.$settings['user'].':'.$settings['group'].' '.$homeRoot);

        shell_exec('chown -R '.$settings['user'].':'.$settings['group'].' '.$settings['domainRoot']);
        shell_exec('chown -R '.$settings['user'].':'.$settings['group'].' '.$settings['domainPublic']);

        shell_exec('chmod -R 775 '.$allDomainsRoot);
        shell_exec('chmod -R 775 '.$homeRoot);

        shell_exec('chmod -R 775 '.$settings['domainRoot']);
        shell_exec('chmod -R 775 '.$settings['domainPublic']);

        shell_exec('systemctl reload apache2');

        return [
            'domain' => $this->domain,
            'domainPublic' => $settings['domainPublic'],
            'domainRoot' => $settings['domainRoot'],
            'homeRoot' => $settings['homeRoot'],
            'user' => $this->user,
            'email' => $this->email,
            'linuxUser' => $linuxUser,
            'apache2Sample' => $apache2Sample,
        ];

    }
}
