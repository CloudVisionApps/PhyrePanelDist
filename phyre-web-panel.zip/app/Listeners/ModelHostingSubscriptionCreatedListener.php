<?php

namespace App\Listeners;

use App\Actions\CreateLinuxWebUser;
use App\Actions\GetLinuxUser;
use App\Events\ModelHostingSubscriptionCreated;
use App\Models\Customer;
use App\Models\Domain;
use App\Models\HostingSubscription;
use Illuminate\Support\Str;

class ModelHostingSubscriptionCreatedListener
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     */
    public function handle(ModelHostingSubscriptionCreated $event): void
    {

        $findHostingSubscription = HostingSubscription::where('id', $event->model->id)->first();
        if (! $findHostingSubscription) {
            return;
        }
        $findCustomer = Customer::where('id', $event->model->customer_id)->first();
        if (! $findCustomer) {
            return;
        }

        $systemUsername = $this->_generateUsername($event->model->domain);
        $systemUsername = $systemUsername.$findCustomer->id.$findHostingSubscription->id;

        $getLinuxUser = new GetLinuxUser();
        $getLinuxUser->setUsername($systemUsername);
        $linuxUser = $getLinuxUser->handle();

        if (! empty($linuxUser)) {
            $systemUsername = $this->_generateUsername(Str::random(10));
            $systemUsername = $systemUsername.$findCustomer->id.$findHostingSubscription->id;
        }

        $systemPassword = Str::random(14);

        $createLinuxWebUser = new CreateLinuxWebUser();
        $createLinuxWebUser->setUsername($systemUsername);
        $createLinuxWebUser->setPassword($systemPassword);
        $createLinuxWebUserOutput = $createLinuxWebUser->handle();

        if (strpos($createLinuxWebUserOutput, 'Creating home directory') !== false) {

            $findHostingSubscription->system_username = $systemUsername;
            $findHostingSubscription->system_password = $systemPassword;
            $findHostingSubscription->save();

            $makeMainDomain = new Domain();
            $makeMainDomain->hosting_subscription_id = $findHostingSubscription->id;
            $makeMainDomain->domain = $findHostingSubscription->domain;
            $makeMainDomain->is_main = 1;
            $makeMainDomain->save();

        }

    }

    private static function _generateUsername($string)
    {
        $removedMultispace = preg_replace('/\s+/', ' ', $string);
        $sanitized = preg_replace('/[^A-Za-z0-9\ ]/', '', $removedMultispace);
        $lowercased = strtolower($sanitized);
        $lowercased = str_replace(' ', '', $lowercased);
        $lowercased = trim($lowercased);
        if (strlen($lowercased) > 10) {
            $lowercased = substr($lowercased, 0, 10);
        }

        $username = $lowercased.rand(1111, 9999).Str::random(4);
        $username = strtolower($username);

        return $username;
    }
}
