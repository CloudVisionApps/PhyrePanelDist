<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Database extends Model
{
    use HasFactory;

    protected $fillable = [
        'hosting_subscription_id',
        'name',
        'username',
        'password',
        'description',
    ];

    public static function boot()
    {
        parent::boot();

        static::created(function ($model) {

            $findHostingSubscription = HostingSubscription::where('id', $model->hosting_subscription_id)->first();
            if (!$findHostingSubscription) {
                return false;
            }

            $databaseUsername = $findHostingSubscription->system_username . '_' . $model->username;
            $databasePassword = $model->password;

            $findDatabaseUser = DatabaseUser::where('username', $databaseUsername)
                ->where('database_id', $model->id)
                ->first();

            if ($findDatabaseUser) {
                return false;
            }

            $createDatabaseUser = DatabaseUser::create([
                'database_id' => $model->id,
                'username' => $databaseUsername,
                'password' => $databasePassword,
            ]);

            if (!$createDatabaseUser) {
                return false;
            }

            unset($model->username);
            unset($model->password);


        });
    }

    public function hostingSubscription()
    {
        return $this->belongsTo(HostingSubscription::class);
    }

    public function databaseUsers()
    {
        return $this->hasMany(DatabaseUser::class);
    }
}
