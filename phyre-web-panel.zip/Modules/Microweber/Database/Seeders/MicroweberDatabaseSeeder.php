<?php

namespace Modules\Microweber\Database\Seeders;

use Illuminate\Database\Seeder;

class MicroweberDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
