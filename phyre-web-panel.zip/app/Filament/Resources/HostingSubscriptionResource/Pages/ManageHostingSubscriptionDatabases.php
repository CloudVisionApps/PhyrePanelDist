<?php

namespace app\Filament\Resources\HostingSubscriptionResource\Pages;


use App\Filament\Resources\Blog\PostResource;
use App\Filament\Resources\HostingSubscriptionResource;
use App\Models\RemoteDatabaseServer;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Infolists\Components\IconEntry;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Infolist;
use Filament\Resources\Pages\ManageRelatedRecords;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Contracts\Support\Htmlable;

class ManageHostingSubscriptionDatabases extends ManageRelatedRecords
{
    protected static string $resource = HostingSubscriptionResource::class;

    protected static string $relationship = 'databases';

    protected static ?string $navigationIcon = 'heroicon-o-circle-stack';

    public function getTitle(): string | Htmlable
    {
        $recordTitle = $this->getRecordTitle();

        $recordTitle = $recordTitle instanceof Htmlable ? $recordTitle->toHtml() : $recordTitle;

        return "Manage {$recordTitle} Databases";
    }

    public function getBreadcrumb(): string
    {
        return 'Databases';
    }

    public static function getNavigationLabel(): string
    {
        return 'Manage Databases';
    }

    public function form(Form $form): Form
    {

        $systemUsername = $this->record->system_username;

        return $form
            ->schema([

                Forms\Components\ToggleButtons::make('is_remote_database_server')
                    ->default('internal')
                    ->live()
                    ->options([
                        'no' => 'Internal',
                        'yes' => 'Remote Database Server',
                    ])->inline(),

                Forms\Components\Select::make('remote_database_server_id')
                    ->label('Remote Database Server')
                    ->hidden(fn(Forms\Get $get): bool => 'yes' !== $get('is_remote_database_server'))
                    ->options(
                        RemoteDatabaseServer::all()->pluck('name', 'id')
                    ),

                Forms\Components\TextInput::make('name')
                    ->prefix($systemUsername.'_')
                    ->label('Database Name')
                    ->required(),

            ])
            ->columns(1);
    }

    public function infolist(Infolist $infolist): Infolist
    {
        return $infolist
            ->columns(1)
            ->schema([
                TextEntry::make('title'),
                TextEntry::make('customer.name'),
                IconEntry::make('is_visible')
                    ->label('Visibility'),
                TextEntry::make('content')
                    ->markdown(),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('title')
            ->columns([
                Tables\Columns\TextColumn::make('title')
                    ->label('Title')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('customer.name')
                    ->label('Customer')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\IconColumn::make('is_visible')
                    ->label('Visibility')
                    ->sortable(),
            ])
            ->filters([
                //
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make(),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->groupedBulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }
}
