<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HostingSubscription extends Model
{
    use HasFactory;

    protected $fillable = [
        'phyre_server_id',
        'domain',
        'customer_id',
        'hosting_plan_id',
        'system_username',
        'system_password',
        'description',
        'setup_date',
        'expiry_date',
        'renewal_date',
    ];

    public static function boot()
    {
        parent::boot();

        static::created(function ($model) {
            event(new \App\Events\ModelHostingSubscriptionCreated($model));
        });

        static::deleting(function ($model) {
            event(new \App\Events\ModelHostingSubscriptionDeleting($model));
        });

    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function hostingPlan()
    {
        return $this->belongsTo(HostingPlan::class);
    }
}
