<?php

namespace Modules\LetsEncrypt\Filament\Clusters\LetsEncrypt\Pages;

use Filament\Actions\Action;
use Filament\Forms\Components\Checkbox;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Modules\LetsEncrypt\Filament\Clusters\LetsEncryptCluster;
use Outerweb\FilamentSettings\Filament\Pages\Settings as BaseSettings;

class MasterDomain extends BaseSettings
{
    protected static ?string $navigationGroup = 'Let\'s Encrypt';

    protected static ?string $cluster = LetsEncryptCluster::class;

    protected static ?string $navigationIcon = 'heroicon-o-adjustments-horizontal';

    protected static ?int $navigationSort = 3;

    public static function getNavigationLabel() : string
    {
        return 'Master Domain';
    }
    public function getFormActions() : array
    {
        return [
            Action::make('install')
                ->label('Install Certificates')
                ->action('installCertificates'),
        ];
    }

    public function installCertificates()
    {

    }

    public function schema(): array
    {
        return [

            Section::make('MasterDomain')
                ->schema([

                    TextInput::make('master_domain')
                        ->placeholder(setting('general.master_domain'))
                        ->disabled(),

                    Checkbox::make('install_wildcard_on_master_domain')
                        ->label('Install Wildcard Certificate on Master Domain')
                        ->helperText('Wildcard certificate will be installed on *.'.setting('general.master_domain')),

                ]),
        ];
    }
}
