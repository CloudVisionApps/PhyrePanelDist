<?php

namespace Modules\LetsEncrypt\Filament\Clusters\LetsEncryptResource\Pages;
use Modules\LetsEncrypt\Filament\Admin\Resources\LetsEncryptCertificateResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListLetsEncryptCertificates extends ListRecords
{
    protected static string $resource = LetsEncryptCertificateResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
