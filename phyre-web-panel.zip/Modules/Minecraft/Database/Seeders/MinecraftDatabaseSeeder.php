<?php

namespace Modules\Minecraft\Database\Seeders;

use Illuminate\Database\Seeder;

class MinecraftDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
