<div>
    <div wire:poll="installLog" class="text-left text-sm font-medium text-gray-950 dark:text-white h-[20rem] overflow-y-scroll">

        {!! $this->install_log !!}

    </div>
</div>
