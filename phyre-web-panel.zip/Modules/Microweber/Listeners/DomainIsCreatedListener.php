<?php

namespace Modules\Microweber\Listeners;

use App\Events\DomainIsCreated;
use App\Models\Domain;
use App\Models\HostingPlan;
use App\Models\HostingSubscription;
use Modules\Microweber\App\Models\MicroweberInstallation;

class DomainIsCreatedListener
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     */
    public function handle(DomainIsCreated $event): void
    {
        $findDomain = Domain::where('id', $event->model->id)->first();
        if (! $findDomain) {
            return;
        }
        $findHostingSubscription = HostingSubscription::where('id', $findDomain->hosting_subscription_id)->first();
        if (! $findHostingSubscription) {
            return;
        }
        $findHostingPlan = HostingPlan::where('id', $findHostingSubscription->hosting_plan_id)->first();
        if (! $findHostingPlan) {
            return;
        }

        if (! in_array('microweber', $findHostingPlan->additional_services)) {
            return;
        }

       // $phyreShellExecutor = new \Modules\Microweber\Shell\Adapters\PhyreShellExecutor();

        $installationType = 'symlink';
        $installationLanguage = 'bg';
        $installationTemplate = 'shopmag';

        $install = new \MicroweberPackages\SharedServerScripts\MicroweberInstaller();
       // $install->setShellExecutor($phyreShellExecutor);
        $install->setChownUser($findDomain->domain_username);
        $install->enableChownAfterInstall();

        $install->setPath($findDomain->domain_public);
        $install->setSourcePath(config('microweber.sharedPaths.app'));

        $install->setLanguage($installationLanguage);
        //$install->setTemplate($installationTemplate);

        //  $install->setStandaloneInstallation();
        $install->setSymlinkInstallation();
        $install->setDatabaseDriver('sqlite');

        $install->setAdminEmail('bojotjo@abv.bg');
        $install->setAdminUsername('bojotjo');
        $install->setAdminPassword('bojotjo');

        $status = $install->run();

        if (isset($status['success']) && $status['success']) {

            $whiteLabelSettings = [];
            $whiteLabelSettings['website_manager_url'] = 'https://dev.microweber.com';

            $whitelabel = new \MicroweberPackages\SharedServerScripts\MicroweberWhitelabelSettingsUpdater();
            $whitelabel->setPath($findDomain->domain_public);
            $whitelabel->apply($whiteLabelSettings);

            $findInstallation = MicroweberInstallation::where('installation_path', $findDomain->domain_public)
                ->where('domain_id', $findDomain->id)
                ->first();

            if (! $findInstallation) {
                $findInstallation = new MicroweberInstallation();
                $findInstallation->domain_id = $findDomain->id;
                $findInstallation->installation_path = $findDomain->domain_public;
            }

            $findInstallation->app_version = 'latest';
            //$findInstallation->template = $installationTemplate;

            if ($installationType == 'symlink') {
                $findInstallation->installation_type = 'symlink';
            } else {
                $findInstallation->installation_type = 'standalone';
            }

            $findInstallation->save();

        }

    }
}
