<?php

namespace Modules\Docker\Database\Seeders;

use Illuminate\Database\Seeder;

class DockerDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
