<VirtualHost *:{{$port}}>


    ServerName {{$domain}}
    DocumentRoot {{$domainPublic}}
    SetEnv APP_DOMAIN {{$domain}}

    @if(isset($enableRuid2) and $enableRuid2)
    #RDocumentChRoot {{$domainPublic}}
    SuexecUserGroup {{$user}} {{$group}}
    RUidGid {{$user}} {{$group}}
    @endif



    <Directory {{$domainPublic}}>
        Options Indexes FollowSymLinks MultiViews
        AllowOverride All
        Require all granted
        @if(isset($enableRuid2) and $enableRuid2)
        RMode config
        RUidGid {{$user}} {{$group}}
        @endif

        @php
        $appendOpenBaseDirs = $homeRoot;
        if (isset($phpAdminValueOpenBaseDirs)
                && is_array($phpAdminValueOpenBaseDirs)
                && !empty($phpAdminValueOpenBaseDirs)) {
            $appendOpenBaseDirs .= ':' . implode(':', $phpAdminValueOpenBaseDirs);
        }
        @endphp
        php_admin_value open_basedir {{$appendOpenBaseDirs}}

        php_admin_value upload_tmp_dir {{$homeRoot}}/tmp
        php_admin_value session.save_path {{$homeRoot}}/tmp
        php_admin_value sys_temp_dir {{$homeRoot}}/tmp

    </Directory>


    @if(isset($ssl) and $ssl)
        #SSLEngine on
        #SSLCertificateFile /etc/ssl/certs/{{$domain}}.crt
        #SSLCertificateKeyFile /etc/ssl/private/{{$domain}}.key
    @endif

</VirtualHost>

