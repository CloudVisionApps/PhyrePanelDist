<?php

namespace App\Models;

use App\DatabaseManager;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Database extends Model
{
    use HasFactory;

    protected $fillable = [
        'hosting_subscription_id',
        'remote_database_server_id',
        'is_remote_database_server',
        'database_name',
        'description',
    ];

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {

            $findHostingSubscription = HostingSubscription::where('id', $model->hosting_subscription_id)->first();
            if (!$findHostingSubscription) {
                return false;
            }

            if ($model->is_remote_database_server == 1) {
                $remoteDatabaseServer = RemoteDatabaseServer::find($model->remote_database_server_id);
                if (!$remoteDatabaseServer) {
                    return false;
                }

                $databaseManager = new DatabaseManager(
                    $remoteDatabaseServer->host,
                    $remoteDatabaseServer->port,
                    $remoteDatabaseServer->username,
                    $remoteDatabaseServer->password,
                    null
                );

                $databaseName = Str::slug($model->database_name, '_');
                $databaseName = $findHostingSubscription->system_username . '_' . $databaseName;
                $databaseName = strtolower($databaseName);
                $createDatabase = $databaseManager->createDatabase($databaseName);

                if ($createDatabase) {
                    $model->database_name = $databaseName;
                } else {
                    return false;
                }
            }

            return $model;

        });

        static::deleting(function($model) {

            if ($model->is_remote_database_server == 1) {
                $remoteDatabaseServer = RemoteDatabaseServer::where('id', $model->remote_database_server_id)->first();
                if (!$remoteDatabaseServer) {
                    return false;
                }

                $databaseManager = new DatabaseManager(
                    $remoteDatabaseServer->host,
                    $remoteDatabaseServer->port,
                    $remoteDatabaseServer->username,
                    $remoteDatabaseServer->password
                );

                $deleteDatabase = $databaseManager->deleteDatabase($model->database_name);
                if ($deleteDatabase) {
                    return true;
                } else {
                    return false;
                }
            }
        });
    }

    public function hostingSubscription()
    {
        return $this->belongsTo(HostingSubscription::class);
    }

    public function databaseUsers()
    {
        return $this->hasMany(DatabaseUser::class);
    }
}
