<?php

namespace App\Models;

use App\ApiSDK\PhyreApiSDK;
use App\Events\ModelPhyreServerCreated;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use phpseclib3\Net\SSH2;

class PhyreServer extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'ip',
        'port',
        'username',
        'password',
    ];

    public static function boot()
    {
        parent::boot();

        static::created(function ($model) {
            event(new ModelPhyreServerCreated($model));
        });

    }

    public function syncResources()
    {
        // Sync customers
        $customerExternalIds = [];
        $getCustomers = Customer::where('phyre_server_id', $this->id)->get();
        if ($getCustomers->count() > 0) {
            foreach ($getCustomers as $customer) {
                $customerExternalIds[] = $customer->external_id;
            }
        }
        $phyreApiSDK = new PhyreApiSDK($this->ip, 8443, $this->username, $this->password);
        $getExternalCustomers = $phyreApiSDK->getCustomers();
        if (isset($getExternalCustomers['data']['customers'])) {
            $externalCustomerIds = [];
            foreach ($getExternalCustomers['data']['customers'] as $externalCustomer) {
                $externalCustomerIds[] = $externalCustomer['id'];
            }

            // Delete customers to main server that are not in external server
            foreach ($customerExternalIds as $customerExternalId) {
                if (!in_array($customerExternalId, $externalCustomerIds)) {
                    $getCustomer = Customer::where('external_id', $customerExternalId)->first();
                    if ($getCustomer) {
                        $getCustomer->delete();
                    }
                }
            }
            // Add customers to main server from external server
            foreach ($getExternalCustomers['data']['customers'] as $externalCustomer) {
                $findCustomer = Customer::where('external_id', $externalCustomer['id'])
                    ->where('phyre_server_id', $this->id)
                    ->first();
                if (!$findCustomer) {
                    $findCustomer = new Customer();
                    $findCustomer->phyre_server_id = $this->id;
                    $findCustomer->external_id = $externalCustomer['id'];
                }
                $findCustomer->name = $externalCustomer['name'];
                $findCustomer->username = $externalCustomer['username'];
                $findCustomer->email = $externalCustomer['email'];
                $findCustomer->phone = $externalCustomer['phone'];
                $findCustomer->address = $externalCustomer['address'];
                $findCustomer->city = $externalCustomer['city'];
                $findCustomer->state = $externalCustomer['state'];
                $findCustomer->zip = $externalCustomer['zip'];
                $findCustomer->country = $externalCustomer['country'];
                $findCustomer->company = $externalCustomer['company'];
                $findCustomer->saveQuietly();
            }
        }



//        // Sync Hosting Plans
//        $getHostingPlans = HostingPlan::all();
//        if ($getHostingPlans->count() > 0) {
//            foreach ($getHostingPlans as $hostingPlan) {
//
//            }
//        }
    }

    public function updateServer()
    {
        $ssh = new SSH2($this->ip);
        if ($ssh->login($this->username, $this->password)) {

            $output = $ssh->exec('cd /usr/local/phyre/web && /usr/local/phyre/php/bin/php artisan apache:ping-websites-with-curl');
            dd($output);

            $output = '';
            $output .= $ssh->exec('wget https://raw.githubusercontent.com/CloudVisionApps/PhyrePanel/main/update/update-web-panel.sh -O /usr/local/phyre/update/update-web-panel.sh');
            $output .= $ssh->exec('chmod +x /usr/local/phyre/update/update-web-panel.sh');
            $output .= $ssh->exec('/usr/local/phyre/update/update-web-panel.sh');

            dd($output);

            $this->healthCheck();
        }
    }

    public function healthCheck()
    {
        try {
            $phyreApiSDK = new PhyreApiSDK($this->ip, 8443, $this->username, $this->password);
            $response = $phyreApiSDK->healthCheck();
            if (isset($response['status']) && $response['status'] == 'ok') {
                $this->status = 'Online';
                $this->save();
            } else {
                $this->status = 'Offline';
                $this->save();
            }
        } catch (\Exception $e) {
            $this->status = 'Offline';
            $this->save();
        }

    }

}
