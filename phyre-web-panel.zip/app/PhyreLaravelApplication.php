<?php

namespace App;

use Illuminate\Foundation\Application;

/**
 * @property \App\VirtualHosts\ApacheVirtualHostManager $virtualHostManager
 */
class PhyreLaravelApplication extends Application
{
}
