<?php

namespace Modules\Terminal\Database\Seeders;

use Illuminate\Database\Seeder;

class TerminalDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
