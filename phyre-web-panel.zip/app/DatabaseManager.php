<?php

namespace app;

class DatabaseManager
{
    public $host;
    public $port;

    public $username;
    public $password;

    public $database =  null;

    public function __construct($host, $port, $username, $password, $database)
    {
        $this->host = $host;
        $this->port = $port;

        $this->username = $username;
        $this->password = $password;

        $this->database = $database;
    }

    public function createDatabase($databaseName)
    {

    }

    public function deleteDatabase($databaseName)
    {

    }

    public function createDatabaseUser($username, $password)
    {

    }
    public function deleteDatabaseUser($username)
    {

    }

}
