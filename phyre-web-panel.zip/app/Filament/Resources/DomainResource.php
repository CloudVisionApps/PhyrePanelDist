<?php

namespace App\Filament\Resources;

use App\Filament\Resources\DomainResource\Pages;
use App\Models\Domain;
use Filament\Actions\ViewAction;
use Filament\Forms\Components\Actions;
use Filament\Forms\Components\KeyValue;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Tabs;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class DomainResource extends Resource
{
    protected static ?string $model = Domain::class;

    protected static ?string $navigationIcon = 'heroicon-o-globe-europe-africa';

    protected static ?string $navigationGroup = 'Hosting Services';

    protected static ?int $navigationSort = 3;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([

                Tabs::make('Tabs')
                    ->tabs([
                        Tabs\Tab::make('General')
                            ->schema([
                                TextInput::make('domain')
                                    ->label('Domain')
                                    ->columnSpanFull()
                                    ->disabled(),

                                Select::make('server_application_type')
                                    ->options([
                                        'apache_php' => 'Apache + PHP',
                                        'apache_nodejs' => 'Apache + Node.js',
                                        'apache_python' => 'Apache + Python',
                                        'apache_ruby' => 'Apache + Ruby',
                                    ])
                                    ->columnSpanFull()
                                    ->default('apache_php')
                                    ->label('Server application type'),
                            ]),
                        Tabs\Tab::make('Git')
                            ->schema([

                                TextInput::make('git_repository_url')
                                    ->label('Repository URL'),

                                Actions::make([

                                    Actions\Action::make('clone_repository')
                                        //  ->icon('heroicon-m-refresh')
                                        //->requiresConfirmation()
                                        ->action(function(Get $get, $record) {
                                            // Run command
                                            $domainPublic = $record->domain_public;
                                            $gitRepositoryUrl = $get('git_repository_url');

                                            shell_exec('rm -rf ' . $domainPublic);
                                            $command = 'git clone '.$gitRepositoryUrl . ' ' . $domainPublic;
                                            $output = shell_exec($command);

                                            
                                        }),

                                ]),


                            ]),

                        Tabs\Tab::make('Node.js')
                            ->schema([

                                Tabs::make('Tabs Node.js')
                                    ->tabs([

                                Tabs\Tab::make('Dashboard')
                                    ->schema([

                                Actions::make([

                                    Actions\Action::make('restart_nodejs')
                                      //  ->icon('heroicon-m-refresh')
                                        ->requiresConfirmation()
                                        ->action(function() {
                                            // Restart Node.js
                                        }),

                               ]),

                               Select::make('nodejs_version')
                                    ->label('Node.js version')
                                    ->options([
                                        '14.x' => '14.x',
                                        '16.x' => '16.x',
                                    ])
                                    ->columnSpanFull()
                                    ->default('14.x'),

                                Select::make('package_manager')
                                    ->label('Package manager')
                                    ->options([
                                        'npm' => 'npm',
                                        'yarn' => 'yarn',
                                    ])
                                    ->columnSpanFull()
                                    ->default('npm'),

                                TextInput::make('document_root')
                                    ->label('Document root')
                                    ->columnSpanFull()
                                    ->default('/public_html'),

                                Select::make('application_mode')
                                    ->label('Application mode')
                                    ->options([
                                        'development' => 'Development',
                                        'production' => 'Production',
                                    ])
                                    ->columnSpanFull()
                                    ->default('production'),

                                TextInput::make('application_startup_file')
                                    ->label('Application startup file')
                                    ->columnSpanFull()
                                    ->default('app.js'),

                                KeyValue::make('custom_environment_variables')
                                    ->label('Custom Environment variables')
                                    ->columnSpanFull()
                                    ->helperText('Add custom environment variables for your Node.js application. Separate key and value with an equal sign. Example: KEY=VALUE')

                                 ]),

                                        Tabs\Tab::make('Run Node.js commands')
                                            ->schema([

                                                Select::make('node_version')
                                                    ->label('Node.js version')
                                                    ->options([
                                                        '14.x' => '14.x',
                                                        '16.x' => '16.x',
                                                    ])
                                                    ->default('14.x'),

                                                Select::make('package_manager')
                                                    ->label('Package manager')
                                                    ->options([
                                                        'npm' => 'npm',
                                                        'yarn' => 'yarn',
                                                    ])
                                                    ->default('npm'),

                                                TextInput::make('command')
                                                    ->label('Command')
                                                    ->default('start'),

                                                Actions::make([

                                                    Actions\Action::make('run_command')
                                                        //  ->icon('heroicon-m-refresh')
                                                        ->requiresConfirmation()
                                                        ->action(function() {
                                                            // Run command
                                                        }),

                                                ]),


                                        ]),

                                ])

                            ]),
                    ])
                    ->columnSpanFull()
                    ->activeTab(1),

            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('domain')
                    ->searchable()
                    ->sortable(),

                //                Tables\Columns\TextColumn::make('hostingPlan.name')
                //                    ->searchable()
                //                    ->sortable(),

                //                Tables\Columns\TextColumn::make('customer.name')
                //                    ->searchable()
                //                    ->sortable(),

            ])
            ->defaultSort('id', 'desc')
            ->filters([
                //
            ])
            ->actions([

                Tables\Actions\Action::make('visit')
                    ->label('Open website')
                    ->icon('heroicon-m-arrow-top-right-on-square')
                    ->color('gray')
                    ->url(fn ($record): string => 'http://'.$record->domain, true),

                Tables\Actions\EditAction::make(),

            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    //  Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListDomains::route('/'),
            //  'create' => Pages\CreateWebsite::route('/create'),
            'edit' => Pages\EditDomain::route('/{record}/edit'),
//            'view' => Pages\ViewDomain::route('/{record}'),
        ];
    }
}
