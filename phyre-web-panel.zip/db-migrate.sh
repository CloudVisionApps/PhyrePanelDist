PHYRE_PHP=/usr/local/phyre/php/bin/php

rm -rf composer.lock
$PHYRE_PHP composer.phar i --no-interaction --no-progress
$PHYRE_PHP composer.phar dump-autoload --no-interaction --no-progress

$PHYRE_PHP artisan migrate

#$PHYRE_PHP artisan l5-swagger:generate
