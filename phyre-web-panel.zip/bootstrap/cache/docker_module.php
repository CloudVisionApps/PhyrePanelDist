<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Docker\\App\\Providers\\DockerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Docker\\App\\Providers\\DockerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);