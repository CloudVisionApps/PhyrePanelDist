<?php

namespace Modules\LetsEncrypt\Clusters;

use Filament\Clusters\Cluster;

class LetsEncrypt extends Cluster
{
    protected static ?string $navigationIcon = 'heroicon-o-squares-2x2';
}
