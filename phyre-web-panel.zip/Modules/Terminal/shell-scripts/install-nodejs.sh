sudo apt-get install net-tools npm nodejs -y
cd /usr/local/phyre/web/Modules/Terminal/nodejs/terminal
npm i

echo "Done!"
